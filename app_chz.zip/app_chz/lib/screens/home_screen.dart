import 'package:flutter/material.dart';
import '../screens/check_cz_screen.dart';
import '../screens/check_local_screen.dart';
import '../screens/settings_screen.dart';
import '../models/settings.dart';

class HomeScreen extends StatelessWidget {
  final AppSettings settings;

  const HomeScreen({super.key, required this.settings});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Главное меню')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          ListTile(
            title: const Text('1. Проверка кода маркировки в ЧЗ'),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => CheckCzScreen(settings: settings),
                ),
              );
            },
          ),
          ListTile(
            title: const Text('2. Проверка кода в локальной системе'),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => CheckLocalScreen(settings: settings),
                ),
              );
            },
          ),
          ListTile(
            title: const Text('3. Настройки'),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => SettingsScreen(settings: settings),
                ),
              );
            },
          ),
        ],
      ),
    );
  }
}
