import 'package:flutter/material.dart';
import '../models/settings.dart';

class SettingsScreen extends StatefulWidget {
  final AppSettings settings;
  const SettingsScreen({super.key, required this.settings});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  late TextEditingController _czUrlController;
  late TextEditingController _localUrlController;
  late TextEditingController _tokenController;

  @override
  void initState() {
    super.initState();
    _czUrlController = TextEditingController(text: widget.settings.czApiUrl);
    _localUrlController = TextEditingController(text: widget.settings.localApiUrl);
    _tokenController = TextEditingController(text: widget.settings.bearerToken);
  }

  void _saveSettings() {
    // Здесь можно сохранить настройки (SharedPreferences, файл, БД)
    // Для прототипа просто покажем сообщение
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Настройки сохранены (в памяти)')),
    );
    // Обновляем объект settings, если он передаётся дальше — лучше использовать State Management
  }

  @override
  void dispose() {
    _czUrlController.dispose();
    _localUrlController.dispose();
    _tokenController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Настройки')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TextField(
              controller: _czUrlController,
              decoration: const InputDecoration(
                labelText: 'URL для проверки в ЧЗ (TrueAPI)',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _localUrlController,
              decoration: const InputDecoration(
                labelText: 'URL локальной системы',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _tokenController,
              obscureText: true,
              decoration: const InputDecoration(
                labelText: 'Bearer токен',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 24),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: _saveSettings,
                child: const Text('Сохранить'),
              ),
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => Navigator.pop(context),
        tooltip: 'Назад на главный экран',
        child: const Icon(Icons.arrow_back),
      ),
    );
  }
}
