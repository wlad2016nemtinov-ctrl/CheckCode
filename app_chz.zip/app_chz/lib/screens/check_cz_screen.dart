import 'package:flutter/material.dart';
import '../services/api_service.dart';
import '../models/settings.dart';

class CheckCzScreen extends StatefulWidget {
  final AppSettings settings;
  const CheckCzScreen({super.key, required this.settings});

  @override
  State<CheckCzScreen> createState() => _CheckCzScreenState();
}

class _CheckCzScreenState extends State<CheckCzScreen> {
  final TextEditingController _codeController = TextEditingController();
  String _result = '';
  bool _isLoading = false;

  Future<void> _checkCode() async {
    setState(() {
      _isLoading = true;
      _result = '';
    });
    try {
      final data = await ApiService.checkCzCode(_codeController.text, widget.settings);
      setState(() {
        _result = 'Результат: ${data.toString()}';
      });
    } catch (e) {
      setState(() {
        _result = 'Ошибка: $e';
      });
    } finally {
      setState(() => _isLoading = false);
    }
  }

  @override
  void dispose() {
    _codeController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Проверка кода маркировки в ЧЗ'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TextField(
              controller: _codeController,
              decoration: const InputDecoration(
                labelText: 'Код маркировки',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: _isLoading ? null : _checkCode,
              child: _isLoading
                  ? const SizedBox(
                      width: 20, height: 20,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    )
                  : const Text('Проверить'),
            ),
            const SizedBox(height: 16),
            Text(_result),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => Navigator.pop(context),
        tooltip: 'Назад на главный экран',
        child: const Icon(Icons.arrow_back),
      ),
    );
  }
}
