import 'dart:convert';

import 'package:flutter/material.dart';
import '../services/api_service.dart';
import '../models/settings.dart';

class CheckLocalScreen extends StatefulWidget {
  final AppSettings settings;
  const CheckLocalScreen({super.key, required this.settings});

  @override
  State<CheckLocalScreen> createState() => _CheckLocalScreenState();
}

class _CheckLocalScreenState extends State<CheckLocalScreen> {
  final TextEditingController _urlController = TextEditingController();
  final TextEditingController _headersController = TextEditingController();
  final TextEditingController _bodyController = TextEditingController();

  String _method = 'GET';
  String _result = '';
  bool _isLoading = false;

  Future<void> _sendRequest() async {
    setState(() {
      _isLoading = true;
      _result = '';
    });

    // Парсим заголовки как JSON: {"key":"value",...}
    Map<String, String> headers = {};
    try {
      final parsed = jsonDecode(_headersController.text) as Map<dynamic, dynamic>;
      headers = parsed.map((k, v) => MapEntry(k.toString(), v.toString()));
    } catch (e) {
      setState(() {
        _result = 'Ошибка парсинга заголовков: $e';
        _isLoading = false;
      });
      return;
    }

    try {
      final data = await ApiService.sendLocalRequest(
        urlString: _urlController.text.trim(),
        method: _method,
        headers: headers,
        bodyJson: _method.toUpperCase() == 'POST' ? _bodyController.text : null,
      );
      setState(() {
        _result = 'Ответ сервера: $data';
      });
    } catch (e) {
      setState(() {
        _result = 'Ошибка запроса: $e';
      });
    } finally {
      setState(() => _isLoading = false);
    }
  }

  @override
  void dispose() {
    _urlController.dispose();
    _headersController.dispose();
    _bodyController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Локальная проверка кода')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TextField(
              controller: _urlController,
              decoration: const InputDecoration(
                labelText: 'URL запроса',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _headersController,
              maxLines: 3,
              decoration: const InputDecoration(
                labelText: 'Headers (JSON: {"key":"value"})',
                border: OutlineInputBorder(),
                hintText: '{"Authorization":"Bearer ..."}',
              ),
            ),
            const SizedBox(height: 12),
            DropdownButtonFormField<String>(
              initialValue: _method,
              items: const [
                DropdownMenuItem(value: 'GET', child: Text('GET')),
                DropdownMenuItem(value: 'POST', child: Text('POST')),
              ],
              onChanged: (v) => setState(() => _method = v!),
            ),
            if (_method.toUpperCase() == 'POST') ...[
              const SizedBox(height: 12),
              TextField(
                controller: _bodyController,
                maxLines: 4,
                decoration: const InputDecoration(
                  labelText: 'Тело запроса (JSON)',
                  border: OutlineInputBorder(),
                  hintText: '{"code":"010000..."}',
                ),
              ),
            ],
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: _isLoading ? null : _sendRequest,
              child: _isLoading
                  ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2))
                  : const Text('Отправить'),
            ),
            const SizedBox(height: 16),
            Text(_result),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => Navigator.pop(context),
        tooltip: 'Назад на главный экран',
        child: const Icon(Icons.arrow_back),
      ),
    );
  }
}
