class AppSettings {
  String czApiUrl;
  String localApiUrl;
  String bearerToken;

  AppSettings({
    required this.czApiUrl,
    required this.localApiUrl,
    required this.bearerToken,
  });
}
