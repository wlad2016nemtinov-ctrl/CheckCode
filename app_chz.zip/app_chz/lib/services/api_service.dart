import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/settings.dart';

class ApiService {
  static Future<Map<String, dynamic>> checkCzCode(
    String code,
    AppSettings settings,
  ) async {
    final url = Uri.parse(settings.czApiUrl);
    final headers = {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer ${settings.bearerToken}',
    };
    final body = jsonEncode({'code': code});

    final response = await http.post(url, headers: headers, body: body);

    if (response.statusCode == 200) {
      return jsonDecode(response.body);
    } else {
      throw Exception('Ошибка проверки кода: ${response.statusCode}');
    }
  }

  static Future<Map<String, dynamic>> sendLocalRequest({
    required String urlString,
    required String method, // 'GET' или 'POST'
    required Map<String, String> headers,
    String? bodyJson,
  }) async {
    final uri = Uri.parse(urlString);

    if (method.toUpperCase() == 'POST') {
      final response = await http.post(
        uri,
        headers: headers,
        body: bodyJson,
      );
      if (response.statusCode >= 200 && response.statusCode < 300) {
        return jsonDecode(response.body);
      } else {
        throw Exception('Local POST error: ${response.statusCode}');
      }
    } else {
      // GET
      final response = await http.get(uri, headers: headers);
      if (response.statusCode >= 200 && response.statusCode < 300) {
        return jsonDecode(response.body);
      } else {
        throw Exception('Local GET error: ${response.statusCode}');
      }
    }
  }
}
