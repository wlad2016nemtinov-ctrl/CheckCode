import 'package:flutter/material.dart';
import 'screens/home_screen.dart';
import 'models/settings.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    // Начальные значения — подставь реальные URL и токен
    final initialSettings = AppSettings(
      czApiUrl: 'https://api.crpt.ru/true-api/...', // пример
      localApiUrl: 'http://localhost:8080/check',  // пример
      bearerToken: 'YOUR_BEARER_TOKEN',           // пример
    );

    return MaterialApp(
      title: 'Проверка кодов маркировки',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: HomeScreen(settings: initialSettings),
      debugShowCheckedModeBanner: false,
    );
  }
}
