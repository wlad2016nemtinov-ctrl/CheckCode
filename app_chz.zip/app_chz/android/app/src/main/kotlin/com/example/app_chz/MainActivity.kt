package com.example.app_chz

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
